These are general notes to writing documentation
------------------------------------------------

Authorship

. Edit the *-docinfo.xml to add/edit authorship information.


AsciiDoc Documentation

. AsciiDoc CheatSheet
  http://powerman.name/doc/asciidoc

. AsciiDoc Homepage
  http://www.methods.co.nz/asciidoc/index.html

