The rap
=======

As homage to the tired cliché based on the rap-wrap homonym, we provide the lyrics to our rap anthem:

A PySP State of Mind (The Pyomo Hip Hop)

By Woody and https://www.song-lyrics-generator.org.uk

::

   Yeah, yeah
   Ayo, modeller, it's time.
   It's time, modeller (aight, modeller, begin).
   Straight out the scriptable dungeons of rap.
   
   The cat drops deep as does my map.
   I never program, 'cause to program is the uncle of rap.
   Beyond the walls of scenarios, life is defined.
   I think of optimization under uncertainty when I'm in a PySP state of mind.
   
   Hope the resolution got some institution.
   My revolution don't like no dirty retribution.
   Run up to the distribution and get the evolution.
   
   In a PySP state of mind. 
   
   What more could you ask for? The fast cat?
   You complain about unscriptability.
   I gotta love it though - somebody still speaks for the mat.
   
   I'm rappin' with a cape,
   And I'm gonna move your escape.
   
   Easy, big, indented, like a solution
   Boy, I tell you, I thought you were an institution.
   
   I can't take the unscriptability, can't take the script.
   I woulda tried to code I guess I got no transcript.
   
   Yea, yaz, in a PySP state of mind.
   
   When I was young my uncle had a nondescript.
   I waz kicked out without no manuscript.
   I never thought I'd see that crypt.
   Ain't a soul alive that could take my uncle's transcript.
   
   An object oriented fox is quite the box.
   
   Thinking of optimization under uncertainty.
   Yaz, thinking of optimization under uncertainty
   (optimization under uncertainty).
   
