rapper API
===============

.. automodule:: pyomo.pysp.util.rapper
   :members:
   :undoc-members:
   :show-inheritance:
