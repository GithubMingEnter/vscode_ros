Units Handling in Pyomo
=======================

.. automodule:: pyomo.core.base.units_container

.. autoclass:: PyomoUnitsContainer
   :show-inheritance:
   :members:

.. autoclass:: UnitsError

.. autoclass:: InconsistentUnitsError

