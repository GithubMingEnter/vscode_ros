
Utilities to Build Expressions
==============================

.. autofunction:: pyomo.core.util.prod
.. autofunction:: pyomo.core.util.quicksum
.. autofunction:: pyomo.core.util.sum_product
.. autodata::     pyomo.core.util.summation
.. autodata::     pyomo.core.util.dot_product

