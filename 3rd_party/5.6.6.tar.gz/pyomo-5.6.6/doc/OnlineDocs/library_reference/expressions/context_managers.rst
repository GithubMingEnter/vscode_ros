
Context Managers
================

.. autoclass:: pyomo.core.expr.current.nonlinear_expression
    :members:

.. autoclass:: pyomo.core.expr.current.linear_expression
    :members:

.. autoclass:: pyomo.core.expr.current.clone_counter
    :members:

