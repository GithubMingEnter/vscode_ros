Special Ordered Sets
====================

Summary
~~~~~~~
.. autosummary::

   pyomo.core.kernel.sos.sos
   pyomo.core.kernel.sos.sos1
   pyomo.core.kernel.sos.sos2
   pyomo.core.kernel.sos.sos_tuple
   pyomo.core.kernel.sos.sos_list
   pyomo.core.kernel.sos.sos_dict

Member Documentation
~~~~~~~~~~~~~~~~~~~~
.. autoclass:: pyomo.core.kernel.sos.sos
   :show-inheritance:
   :members:
.. autofunction:: pyomo.core.kernel.sos.sos1
.. autofunction:: pyomo.core.kernel.sos.sos2
.. autoclass:: pyomo.core.kernel.sos.sos_tuple
   :show-inheritance:
   :members:
.. autoclass:: pyomo.core.kernel.sos.sos_list
   :show-inheritance:
   :members:
.. autoclass:: pyomo.core.kernel.sos.sos_dict
   :show-inheritance:
   :members:
