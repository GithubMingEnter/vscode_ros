Utilities for Piecewise Functions
=================================

.. automodule:: pyomo.core.kernel.piecewise_library.util
   :show-inheritance:
   :members:
