.. _apisection:

API
============

.. automodule:: pyomo.contrib.parmest.parmest
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: pyomo.contrib.parmest.graphics
    :members:
    :undoc-members:
    :show-inheritance:
