Getting Help
============

See the Pyomo Forum for online discussions of Pyomo or to ask a question:

* http://groups.google.com/group/pyomo-forum/

Ask a question on StackExchange

* https://stackoverflow.com/questions/ask?tags=pyomo 

Open an issue on GitHub:

* https://github.com/Pyomo/pyomo
