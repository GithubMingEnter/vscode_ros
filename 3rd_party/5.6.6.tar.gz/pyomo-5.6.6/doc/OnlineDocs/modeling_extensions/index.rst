Modeling Extensions
===================

.. toctree::
   :maxdepth: 1

   bilevel.rst
   dae.rst
   mpec.rst
   gdp.rst
   pysp.rst
   network.rst
