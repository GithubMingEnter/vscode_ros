Pyomo Tutorial Examples
=======================

Additional Pyomo tutorials and examples can be found at the following links:

`Prof. Jeffrey Kantor's Pyomo Cookbooks
<https://github.com/jckantor/ND-Pyomo-Cookbook>`_

`Pyomo Gallery
<https://github.com/Pyomo/PyomoGallery>`_


